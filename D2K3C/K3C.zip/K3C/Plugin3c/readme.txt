		Readme of Sting's Hackmap for Diablo II
FEATURES
  1, Compatible with Maphack 5.1. All features in MH 5.1 still work in Hackmap
  2, Show IAS/FCR/MF and lots of stats in character window
  3, Prevent from minimizing window when running in window mode
  4, Target indicators on Minimap guide you MF/pass quickly
  5, Sound prompt when enter a game
  6, Show game server ip

Anti detection features:
  1, Auto unload d2hackmap.dll when extrawork.dll loading.
  2, Integrity scaner show you if the game code is changed.
  3, Anti 64/65 detection.
  4, Safely reveal map for those who only want this function.
     This feature dosent make any change to game code and will do an integrity scan before revealing map for safe.
     
For those who really care about detection, here's smoe advice:
  1, D2loader maybe not safe and can be detected by blizzard so better not to use it. Integrity scaner will show you where exactly it does to game.
  2, Maphack 5.1 edited (and all derived) version is detectable, at least by 65 packet to my knowledge.
 

SIMPLE USE INSTRUCTIONS:

1. Extract all files from D2HACKMAP.ZIP to any folder.

2. Run d2hackmap.exe.

3. Run Diablo II.

4. Alt+tab out of Diablo II. Better do this step after connected to Battle.net if you are going to play on battle.net, otherwise d2hackmap will unload himself when connecting to battle.net.

5. Click "Install/update" to inject d2hackmap.dll into Diablo II process if you want to enjoy full functions. Or click "Reveal Act" to reveal automap of current act when you are in game, it's less function but more safe. You can also customize d2hackmap.exe's behaviour by editing d2hackmap.ini.

6. Alt+tab back to Diablo II and play.
