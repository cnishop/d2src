This package includes the following items:

1, D2hackmap.exe for revealing map on the Battle.Net;
See d2hackmap.ini for settings. This is very important for you to learn how to use it on Battle.Net more safely .

2, d2hackmap.dll for single player. WARNING: It is very detectable, don't use it on Battle.Net!

3, Full source code of d2hackmap.dll.
D2hackmap.dll is derived from Mousepad's Maphack 5.1s, hence their functionality and usage are alike. The full functions can be found in history-en.txt or history-chs.txt (includes all 5.1s features and lots of new features).
One of motivations to release the source code is that for now d2hackmap.dll is for singleplayer because I have no much time for anti-detection (partly done yet). I hope people can learn from it so that they can focus on anti-detection.
